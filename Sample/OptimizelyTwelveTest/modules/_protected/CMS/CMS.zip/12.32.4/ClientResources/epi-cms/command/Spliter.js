//>>built
define("epi-cms/command/Spliter",["dojo/_base/declare","epi/shell/command/_Command"],function(_1,_2){return _1([_2],{isAvailable:false,category:"menuWithSeparator",isSplitter:true});});