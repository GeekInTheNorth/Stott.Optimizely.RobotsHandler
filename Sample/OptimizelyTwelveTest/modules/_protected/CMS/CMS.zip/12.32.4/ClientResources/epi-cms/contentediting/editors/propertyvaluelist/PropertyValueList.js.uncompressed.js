require({cache:{
'url:epi-cms/contentediting/editors/propertyvaluelist/templates/PropertyValueList.html':"<div class=\"epi-property-value-list\" tabindex=\"-1\" role=\"presentation\">\r\n    <div class=\"epi-property-value-list__node\" data-dojo-attach-point=\"listNode\"></div>\r\n    <div data-dojo-attach-point=\"addNode\" class=\"add\"></div>\r\n</div>\r\n"}});
define("epi-cms/contentediting/editors/propertyvaluelist/PropertyValueList", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/keys",

    // dijit
    "dijit/registry",
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/_TemplatedMixin",

    // List modules
    "dgrid/List",
    "dgrid/Keyboard",
    "dgrid/Selection",
    "epi/shell/dgrid/SingleQuery",
    "epi/shell/dgrid/WidgetRow",
    "epi-cms/dgrid/WithContextMenu",

    // epi
    "epi/shell/MetadataTransformer",
    "epi/shell/widget/_ValueRequiredMixin",
    "epi/shell/widget/WidgetFactory",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/command/builder/ButtonBuilder",
    "epi/shell/PropertyMetadata",

    "./viewmodels/PropertyValueListViewModel",
    "./PropertyValueListItem",
    "./PropertyValueListBlockItem",
    "./command/AddPropertyValue",
    "epi-cms/contentediting/ModelPopulation",

    // resources
    "dojo/text!./templates/PropertyValueList.html",
    "epi/i18n!epi/nls/episerver.shared.action"
], function (
    // dojo
    declare,
    lang,
    aspect,
    keys,

    // dijit
    registry,
    _WidgetBase,
    _Container,
    _TemplatedMixin,

    // List modules
    List,
    Keyboard,
    Selection,
    SingleQuery,
    WidgetRow,
    WithContextMenu,

    // epi
    MetadataTransformer,
    _ValueRequiredMixin,
    WidgetFactory,
    _FocusableMixin,
    ButtonBuilder,
    PropertyMetadata,

    PropertyValueListViewModel,
    PropertyValueListItem,
    PropertyValueListBlockItem,
    AddPropertyValueCommand,
    ModelPopulation,

    // resources
    template,
    localization
) {

    var ItemContainer = declare([_WidgetBase, _Container], {
        baseClass: "epi-property-value-item__container"
    });

    var PropertyList = declare([List, SingleQuery, Selection, WithContextMenu, WidgetRow], { stopPropagation: true });

    var PropertyListWithKeyboardSupport = declare([PropertyList, Keyboard]);

    return declare([_WidgetBase, _TemplatedMixin, _ValueRequiredMixin, _FocusableMixin], {
        // summary:
        //      The view for the PropertyValueList. Responsible for creating the PropertyValueList
        //      view model and creating PropertyValueListItems
        // tags:
        //      internal

        templateString: template,

        // multiple: [proteced] Boolean
        //      Used by formmixin to determine whether to inject value as an array or single item
        //      return true
        multiple: true,

        // manualFocusManagement: [protected] Boolean
        //      Skip focus management by the editor wrapper and control editing manually. Each list item editor should handle focus on its own.
        manualFocusManagement: true,

        // value: [public] Array
        //      The widget's value.
        value: null,

        // model: [public] epi-cms/contentediting/editors/propertyvaluelist/viewmodels/PropertyValueListViewModel
        //      Model of the PropertyValueList
        model: null,

        // _listSelectionMode: [readonly] String
        //    List selection mode.
        _listSelectionMode: "single",

        postMixInProperties: function () {
            this.inherited(arguments);

            this.metadataTransformer = this.metadataTransformer || new MetadataTransformer();
            this._widgetFactory = new WidgetFactory();
            this.itemTypeName = this.metadata.customEditorSettings.innerPropertySettings.settings.itemTypeName;
            this.isBlockType = this.metadata.customEditorSettings.innerPropertySettings.settings.isBlockType;
            this.isComplexType = this.metadata.customEditorSettings.innerPropertySettings.settings.isComplexType;

            this.own(
                this.model = this.model || new PropertyValueListViewModel({
                    maxLength: this.maxLength,
                    minLength: this.minLength
                })
            );
        },

        buildRendering: function () {
            this.inherited(arguments);

            this._setupModelWatchers();
            this._setupList();
            this._setupAddCommand();
        },

        startup: function () {
            if (this._started) {
                return;
            }

            this.inherited(arguments);

            if (this.list) {
                this.list.startup();
                this.domNode.style.width = "auto";
            }
        },

        onChange: function (value) {
            // summary:
            //      An extension point invoked when the value has changed.
            // tags:
            //      public
        },

        onStartEdit: function () {
            // summary:
            //		Set this handler to be notified when editing is started.
            // tags:
            //		callback
        },

        onSetInitialValue: function () {
            // summary:
            //		Set this handler to be notified when default value is set.
            // tags:
            //		callback
        },

        isValid: function () {
            // summary:
            //      Returns true if the editor is not required or if it contains one or more items.
            // tags:
            //      protected

            return !this.required || this.model.get("hasValue");
        },

        _getValueAttr: function () {
            // summary:
            //      Gets the values from the model.
            // tags:
            //      private

            return this.model.getFilteredValue();
        },

        _setupModelWatchers: function () {
            // summary:
            //      Sets up all watchers for changes to the model.
            // tags:
            //      private

            var callback = function () {
                if (this.get("readOnly")) {
                    return;
                }

                this.onStartEdit();
                this.onChange(this.get("value"));
            }.bind(this);

            this.own(
                aspect.after(this.model, "moveUp", callback),
                aspect.after(this.model, "moveDown", callback),
                aspect.after(this.model, "remove", callback),
                this.model.on("itemAdded", function (e) {
                    this._onItemAdded(e);
                }.bind(this))
            );
        },

        _setupList: function () {
            // summary:
            //      Creates the list and setup all events.
            // tags:
            //      private

            var preventKeyboardSupport = this.isComplexType || this.isBlockType;
            var ListClass = preventKeyboardSupport ? PropertyList : PropertyListWithKeyboardSupport;

            this.own(
                this.list = new ListClass({
                    "class": "epi-grid-height--auto epi-property-list epi-property-value-list__node",
                    store: this.model.get("store"),
                    commandCategory: "itemContext",
                    deselectOnRefresh: false,
                    tabIndex: -1, // the list itself does not need to have a tabstop
                    maintainOddEven: false,
                    selectionMode: this._listSelectionMode,
                    renderRow: this._renderPropertyValue.bind(this),
                    cellNavigation: true,
                    sort: "default"
                }, this.listNode),

                this.list.on("dgrid-select, dgrid-deselect, dgrid-contextmenu", function () {
                    this._updateSelectedValue();
                }.bind(this)),

                this.list.on("dgrid-contextmenu", function () {
                    // hide any tooltip when showing the context menu
                    this.displayMessage(false);
                }.bind(this))
            );

            if (!preventKeyboardSupport) {
                this.own(
                    this.list.addKeyHandler(keys.DELETE, this._removeItem.bind(this)),
                    this.list.addKeyHandler(keys.UP_ARROW, this._moveItem.bind(this, true)),
                    this.list.addKeyHandler(keys.DOWN_ARROW, this._moveItem.bind(this, false)),
                    this.on("keypress", this._createItem.bind(this))
                );
            }

            this.list.contextMenu.addProvider(this.model);
        },

        _updateSelectedValue: function () {
            // summary:
            //      Updates the selected value
            // tags:
            //      private

            var id = Object.keys(this.list.selection)[0],
                selectedValue = null;

            if (id !== undefined) {
                selectedValue = {
                    id: id,
                    data: this.list.row(id).data
                };
            }

            this.model.set("selectedValue", selectedValue);
        },

        _setupAddCommand: function () {
            // summary:
            //      Sets up the command and assemble it
            // tags:
            //      private

            this.own(this._addPropertyValueCommand = new AddPropertyValueCommand({ model: this.model }));

            var builder = new ButtonBuilder({
                settings: {
                    "class": "epi-chromeless",
                    showLabel: this.isBlockType,
                    label: localization.add + " " + this.itemTypeName
                }
            });
            builder.create(this._addPropertyValueCommand, this.addNode);
        },

        _renderPropertyValue: function (value) {
            // summary:
            //      Renders an either a PropertyValueListBlockItem (for block types) or PropertyValueListItem (for scalar types) for the row and returns its DOM node.
            // tags:
            //      private

            var itemContainer = new ItemContainer();

            var editorDefinition = lang.clone(this.metadata.customEditorSettings.innerPropertySettings);
            editorDefinition.settings.value = this.isBlockType ? ModelPopulation.populateContentModel(value.item, new PropertyMetadata(editorDefinition)) : value.item;
            if (typeof this.get("readOnly") !== "undefined") {
                editorDefinition.settings.readOnly = this.get("readOnly");
            }

            var listItemWidget = this.isBlockType ? new PropertyValueListBlockItem({
                metadata: editorDefinition,
                listItemHeaderFormatter: this._listItemHeaderFormatter.bind(this)
            }) : new PropertyValueListItem({
                widgetFactory: this._widgetFactory,
                isComplexType: this.isComplexType,
                isFullWidth: editorDefinition.settings.isFullWidth,
                editorDefinition: this.metadataTransformer.transformPropertySettings(editorDefinition),
                itemTypeName: this.itemTypeName
            });

            this.onSetInitialValue();

            listItemWidget.own(listItemWidget.on("startEdit", function () {
                this.onStartEdit();
            }.bind(this)));

            listItemWidget.own(listItemWidget.on("change", function (editorValue) {
                this.model.put(value.id, editorValue);
                this._set("value", this.get("value"));
                this.onChange(this.get("value"));
                this.validate();
            }.bind(this)));

            itemContainer.addChild(listItemWidget);

            this.own(itemContainer);

            return itemContainer.domNode;
        },

        _listItemHeaderFormatter: function (value) {
            if (!value || !this.listItemHeaderProperties) {
                return this.itemTypeName;
            }

            var header = this.listItemHeaderProperties.map(function (propertyName) {
                return value[propertyName];
            }).filter(function (propertyValue) {
                return !!propertyValue;
            }).join(" ");

            return header || this.itemTypeName;
        },

        _removeItem: function () {
            this.onStartEdit();
            this.model.remove();
        },

        _moveItem: function (moveUp, event) {
            // summary:
            //      Move the item up or down by pressing CTRL+UP/DOWN.
            // tags:
            //      private

            if (event.ctrlKey) {
                var row = this.list.row(event);
                this.list.focus(row);
                moveUp ? this.model.moveUp() : this.model.moveDown();
            }
        },

        _createItem: function (event) {

            // Exit if focus on text
            if (event.target.type === "text") {
                return;
            }

            if (event.key === "+") {
                this.model.addItem();
                event.preventDefault();
            }
        },

        _onItemAdded: function (e) {
            // summary:
            //      When adding an item, select the new row and focus the editor.
            // tags:
            //      private

            var row = this.list.row(e.itemId);
            if (!row || !row.element) {
                return;
            }

            // setting focus on specific list row will set "dgrid-focus" class on row
            // which keeps menu alvays visible
            var innerListWidget = row.element.firstChild;
            if (this.list.focus) {
                this.list.focus(innerListWidget);
            }

            var widget = registry.byNode(innerListWidget);
            if (widget) {
                if (widget.focus) {
                    widget.focus();
                }

                if (widget.expand) {
                    widget.expand();
                }
            }
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets the values to the model and refreshes the list.
            // tags:
            //      private

            this._set("value", value);
            this.model.set("value", value);
        },

        _setReadOnlyAttr: function (readOnly) {
            // summary:
            //      Sets the readonly setting.
            // tags:
            //      private

            this._set("readOnly", readOnly);
            this.model.set("readOnly", readOnly);

            this.list.set("selectionMode", this.readOnly ? "none" : this._listSelectionMode);
            this.list.refresh();
        }
    });
});
