define(
"dojox/atom/widget/nls/de/FeedEntryViewer", ({
	displayOptions: "[Anzeigeoptionen]",
	title: "Titel",
	authors: "Autoren",
	contributors: "Mitwirkende",
	id: "ID",
	close: "[Schließen]",
	updated: "Aktualisiert",
	summary: "Zusammenfassung",
	content: "Inhalt"
})
);
