//>>built
define("dojox/atom/widget/nls/da/FeedEntryEditor",({doNew:"[ny]",edit:"[redigér]",save:"[gem]",cancel:"[annullér]"}));