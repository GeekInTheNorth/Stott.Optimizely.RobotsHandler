//>>built
define("dojox/atom/widget/nls/de/FeedViewerEntry",({deleteButton:"[Löschen]"}));