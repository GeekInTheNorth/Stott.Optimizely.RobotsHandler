define("epi-find/store/ResourceQueryEngine", [
    "dojo/_base/lang",
    "dojo/store/util/SimpleQueryEngine"
],
    function(lang, SimpleQueryEngine) {
        return function(query, options){
            // Extension for the SimpleQueryEngine that does queries cleanup

            // Remove paging information from the query
            var cleanQuery = lang.clone(query);
            delete cleanQuery.size;
            delete cleanQuery.from;

            return SimpleQueryEngine(cleanQuery, options);
        };
    });