﻿define("epi-find/store/LangMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang"
],
function (declare, lang) {
    return declare(null, {
        // languageParameter: string
        //      The query parameter to send when querying for a specific language.
        languageParameter: null,

        // languagePrefix: string
        //      Prefix of the language value.
        languagePrefix: null,

        // emptyLanguage: string
        //      Value to pass when language is null.
        emptyLanguage: null,

        // addEmptyToQuery: bool
        //      Indicates if emptyLanguage should always be added to the query using the pipe syntax,
        //      even if language is specified
        addEmptyToQuery: false,

        // language: String
        //      The identifying string for the language
        language: null,

        // addToObject: Boolean
        //      Indicates that additional parameters should be added to the object when it is about to be saved
        addToObject: false,

        query: function(query, options) {

            var newQuery = this._addLanguage(lang.clone(query), this.addEmptyToQuery);
            return this.inherited(arguments, [newQuery, options]);
        },

        put: function(object, options){
            if (this.addToObject) {
                object = this._addLanguage(object);
            }
            return this.inherited(arguments, [object, options]);
        },

        _addLanguage: function(/*Object*/ query, /*Boolean*/ addEmpty) {
            // summary:
            //      This method adds information about the current language
            //      to the specified `query` object
            // query: Object
            //      Entity or query where the language parameter should be set
            // addEmpty: Boolean
            //      Indicates that value of `emptyLanguage` property should be
            //      added to the `query` parameter
            // tags:
            //      private
            if (!this.languageParameter || !this.languagePrefix) {
                return query;
            }
            var langQueryValue, existingParam, langValues = [];
            query = query || {};
            if (this.emptyLanguage && (addEmpty || !this.language)) {
                langValues.push(this.languagePrefix + this.emptyLanguage);
            }
            if (this.language) {
                langValues.push(this.languagePrefix + this.language);
            }

            if (langValues.length === 0)
            {
                return query;
            }

            langQueryValue = langValues.join("|");
            existingParam = query[this.languageParameter];
            if (existingParam) {
                if (existingParam instanceof Array) {
                    var exists = false;
                    for (var i=0; i < existingParam.length; i++) {
                        if (existingParam[i].indexOf(this.languagePrefix) === 0) {
                            existingParam[i] = langQueryValue;
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        query[this.languageParameter].push(langQueryValue);
                    }
                } else {
                    query[this.languageParameter] = [existingParam, langQueryValue];
                }
            } else {
                query[this.languageParameter] = [langQueryValue];
            }

            return query;
        },

        setLanguage: function(/* string */ language) {
            // summary:
            //      Sets the language to a new value. 
            //      The language is the identifying language code of the language.
            //      null means all languages
            var oldLanguage = this.language;

            this.language = language;

            if (language !== oldLanguage) {
                this.onLanguageChange(oldLanguage, language);
            }
        },

        // Overridden in children.
        onLanguageChange: function(oldLanguage, newLanguage) {
        }
    });
});
