﻿define("epi-find/Intents", [
    "dojo/_base/config"
],
    function (config) {
        // module:
        //		epi-find/Intents
        return {
            // summary:
            //      A plugin that configures all application intents.
            load: function (id, require, callback) {
                config.intents = {
                    view: {
                        statistics: "manage/statistics",
                        optimization: "manage/optimization",
                        synonyms: "manage/optimization/synonyms",
                        bestBets: "manage/optimization/bestbets",
                        relatedQueries: "manage/optimization/relatedqueries",
                        autocomplete: "manage/optimization/autocomplete",
                        connectors: "configure/connectors",
                        boosting: "configure/boosting",
                        index: "configure/index",
                        overview: "overview/overview",
                        explore: "overview/explore"
                    },

                    create: {
                        synonym: "manage/optimization/synonyms",
                        bestbet: "manage/optimization/bestbets",
                        relatedqueries: "manage/optimization/relatedqueries"
                    }
                };
                callback();
            }
        };
    });