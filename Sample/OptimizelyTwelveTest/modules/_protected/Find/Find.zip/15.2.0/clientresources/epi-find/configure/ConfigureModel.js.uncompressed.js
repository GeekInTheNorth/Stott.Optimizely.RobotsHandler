﻿define("epi-find/configure/ConfigureModel", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/_base/config",

    "dijit/Destroyable",

    "dojox/mvc/getPlainValue",

    "../ConfigModel",
    "./ConnectorModel",
    "./BoostingEditorModel",
    "./BoostingPreviewModel",
    "./IndexModel"
],
function (declare, 
          lang, 
          Stateful, 
          config, 
          Destroyable, 
          getPlainValue, 
          ConfigModel, 
          ConnectorModel,
          BoostingEditorModel, 
          BoostingPreviewModel,
          IndexModel) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      Configure model.

        // connectorModel: epi-find/configure/ConnectorModel
        //      Model for the connectors view
        connectorModel: null,

        indexModel: null,

        boostingEditorModel: null,

        boostingPreviewModel: null,

        _boostingStore: null,
        _boostingPreviewStore: null,

        constructor: function () {
            this._boostingStore = config.dependencies["epi-find.BoostingStore"];
            this._boostingPreviewStore = config.dependencies["epi-find.BoostingPreviewStore"];
        },

        init: function(){
            //  summary:
            //      Sets the model properties to initial state.
            //      This method should be called when widgets are instantiated and subscribed on model updates,
            //      so that when this method is called dependent widgets will get initial values from the model.
            this.connectorModel = new ConnectorModel();

            var self = this;

            this.boostingEditorModel = new BoostingEditorModel({
                store: this._boostingStore,
                invalidateCacheUrl: config.find.siteServiceApiBaseUrl + "editorialboosting/invalidatecache/"
            });

            this.boostingPreviewModel = new BoostingPreviewModel({
                store: this._boostingPreviewStore,
                languages: ConfigModel.config.languages
            });

            this.boostingEditorModel.weightsModel.watch(function() {
                self.boostingPreviewModel.set("weights", getPlainValue(this.model));
            });

            this.indexModel = new IndexModel({indexingPluginUrl: config.find.indexingPluginUrl});
        }
    });
});
