define("epi-find/widget/_HelpMixin", [
    "dojo/_base/declare",
    "dojo/query",
    "dojo/dom-class",

    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/_TemplatedMixin",
    "dijit/form/Button",

    "dojo/i18n!./nls/_HelpMixin",
    "dojo/ready"
], function(declare, query, domClass,
    _WidgetBase, _Container, _TemplatedMixin, Button,
    i18n) {

    var HelpButton = declare([Button], {

        // container: _HelpMixin
        //      The _HelpMixin container widget to toggle "help mode" for
        "class": "epi-chromeless epi-mediumButton epi-help-button",
        iconClass:"epi-iconHelp"
    });

    // module:
    //      epi-find/widget/_HelpMixin

    return declare([_WidgetBase, _TemplatedMixin, _Container], {
        // summary:
        //     Help toggling mixin
        // description:
        //     This mixin toggles the visibility of all elements with the "help" class
        //     when the element with the attachment point "helpButtonNode" is clicked.

        showHelp: false,
        _setShowHelpAttr: function(value) {
            this._set("showHelp", value);
            this._updateLabel();
            this._syncHelp();
        },

        helpClassName: "epi-help",
        activeClassName: "is-active",

        helpContainer: null,
        helpButton: null,
        helpButtonNode: null,

        // globalHelpState: Boolean
        //      Set this to true if one global help state  is desired, false if every instance
        //      should hold its own state (using the classes on the domNodes inside the widget)
        globalHelpState: true,

        postMixInProperties: function() {
            this.inherited(arguments);
            this.helpContainer = this.helpContainer || this.domNode;
        },

        postCreate: function() {
            var self = this;
            this.inherited(arguments);
            if (!this.helpButtonNode) {
                throw new Error("The _HelpMixin should be mixed to a widget that has a domNode reference stored in 'helpButtonNode' property");
            }

            this.helpButton = new HelpButton({
                onClick: function() {
                    self.toggleHelp();
                }
            }, this.helpButtonNode);
            this.own(this.helpButton);
            this._updateLabel();

        },

        startup: function() {
            this.inherited(arguments);
            this._syncHelp();
        },

        toggleHelp: function() {
            this.set("showHelp", !this.showHelp);
        },

        refresh: function() {
            this.set("showHelp", this._isHelpActive());
        },

        _updateLabel: function() {
            if (this.helpButton) {
                this.helpButton.set("label", this.showHelp ? i18n.hideHelp : i18n.showHelp);
            }
        },

        _isHelpActive: function() {
            return this.globalHelpState ? this.showHelp : query("." + this.helpClassName+"."+this.activeClassName, this.helpContainer).length > 0;
        },

        _syncHelp: function() {
            var showHelp = this.showHelp, activeClassName = this.activeClassName;

            query("." + this.helpClassName, this.helpContainer).forEach(function(node) {
                if (showHelp) {
                    domClass.add(node, activeClassName);
                } else {
                    domClass.remove(node, activeClassName);
                }
            });
        }
    });
});