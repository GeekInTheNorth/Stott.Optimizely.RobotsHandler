﻿define("epi-find/Animator", [
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/Deferred",
    "dojo/on",
    "dojo/has",
    "dojo/_base/array",
    "dgrid/util/has-css3"
],

function (lang, domClass, Deferred, on, has, array, hasCss3) {


    has.add("css-transitions", function (global, doc, element) { // TODO: Remove this when has("css-transitions") will be fixed for Chrome in dgrid/util/has-css3
        var cssPrefixes = ["ms", "O", "Moz", "Webkit"];
        var style = element.style,
            i;

        for (i = cssPrefixes.length; i--;) {
            if (style[cssPrefixes[i] + "TransitionProperty"] !== undefined) {
                return cssPrefixes[i]; // vendor-specific css property prefix
            }
        }
        if (style.transitionProperty !== undefined) { // standard, no vendor prefix
            return true;
        }
        return false; // otherwise, not supported
    }, true, true);
    
    has.add("animationend", function(global, doc, element) {
        // summary:
        //      Returns vendor-specific name of the animationEnd CSS property
        var tpfx = has("css-transitions");
        if (!tpfx) { return false; }
        if (tpfx === true) { return "animationend"; }
        return {
            ms: "MSAnimationEnd",
            O: "oanimationend",
            Moz: "animationend",
            Webkit: "webkitAnimationEnd"
        }[tpfx];
    });

    has.add("css-keyframes", function(global, doc, element) {
        // summary:
        //      Returns vendor-specific name of the keyframe CSS property
        var tpfx = has("css-transitions");
        if (!tpfx) { return false; }
        if (tpfx === true) { return "@keyframes"; }
        return {
            ms: "@keyframes",
            O: "@-o-keyframes",
            Moz: "@-moz-keyframes",
            Webkit: "@-webkit-keyframes"
        }[tpfx];
    });

    var exports = {},
    _isAnimationSupported = function () {
        return has("css-transitions");
    },

    _animate = function (/*Node[]*/ animatedNodes, /*String*/ animationEndFunctionName, /*String*/ animationClassName) {
        if (!animatedNodes) {
            throw "No nodes specified for animation";
        }

        if (!lang.isArray(animatedNodes)) {
            animatedNodes = [animatedNodes];
        }

        if (animatedNodes.length === 0) {
            throw "No nodes specified for animation";
        }

        animationClassName = animationClassName || "animate"; // set the default CSS class name for animation if not specified

        var cancelAction = function() {
            // react on cancel
            array.forEach(animatedNodes, function (node) {
                domClass.remove(node, animationClassName);
            });
        };

        var animationEndDeferred = new Deferred(cancelAction);

        var animationStartDeferred = new Deferred(function () {
            cancelAction();
            animationEndDeferred.resolve();
        });

        if (_isAnimationSupported()) {

            // Animation works only if it is applied over the setTimeout
            setTimeout(lang.hitch(this, function () {
                // add animation class to the nodes
                array.forEach(animatedNodes, function (node) {
                    domClass.add(node, animationClassName);
                });
                animationStartDeferred.resolve(animationEndDeferred);

                if (!animationEndFunctionName) {
                    console.warn("animationEndFunctionName should not be undefined!");
                } else {
                    // waiting for animation end only on the first node
                    on.once(animatedNodes[0], animationEndFunctionName, lang.hitch(this, function () {
                        // remove animation class from the nodes
                        array.forEach(animatedNodes, function (node) {
                            domClass.remove(node, animationClassName);
                        });
                        animationEndDeferred.resolve();
                    }));
                }
                
            }), 100);
        } else {
            // css transitions are not supported
            animationEndDeferred.resolve();
            animationStartDeferred.reject(animationEndDeferred);
        }
        return { start: animationStartDeferred, end: animationEndDeferred};
    };

    exports.addKeyFrame = function (rule) {
        var style = document.documentElement.appendChild(document.createElement("style"));
        style.sheet.insertRule(has("css-keyframes") + " " + rule, 0);
    };

    exports.isAnimationSupported = function () {
        // summary:
        //      Returns non-null value if animation is supported
        return _isAnimationSupported();
    };

    exports.transition = function(/*domNode[]*/ animatedNodes, /*String*/ transitionClassName) {
        //  summary: 
        //      Executes animation using CSS transitions. Method returns animationStart Deferred that get resolved 
        //      when animation is started (CSS transitions class is added to the target node).
        //      AnimationEnd Deferred is passed as a value parameter for the resolved animationStart Deferred.
        //      
        //      Typical usage scenario:
        //
        //      var transition = Animator.transition(myAnimatedNode);
        //      transition.start.then(function () {
        //          // do something here with the node for actual animation effect to start: domClass.add or domStyle.set etc.
        //
        //      });
        //      transition.end.then(function () {
        //          // do something here when animation is complete: delete animated node or domClass.remove etc.
        //
        //      });
        //
        //      OR
        //
        //      Animator.transition(myAnimatedNode).start.then(function(animationEnd){
        //          // do something here with the node for actual animation effect to start: domClass.add or domStyle.set etc.
        //
        //          animationEnd.then(function() {
        //              // do something here when animation is complete: delete animated node or domClass.remove etc.
        //
        //          });
        //      });

        return _animate(animatedNodes, has("transitionend"), transitionClassName);

    };

    exports.animation = function (/*domNode[]*/ animatedNodes, /*String*/ animationClassName) {
        //  summary: 
        //      Executes animation using CSS animation. Method returns animationStart Deferred that get resolved 
        //      when animation is started (CSS animation class is added to the target node).
        //      AnimationEnd Deferred is passed as a value parameter for the resolved animationStart Deferred.
        //      
        //      Typical usage scenario is the same as for transition function.
        return _animate(animatedNodes, has("animationend"), animationClassName);
    };
    return exports;
});