require({cache:{
'url:epi-find/widget/templates/Boosting.html':"<div>\n    <p class=\"epi-view--description\">${i18n.description}</p>\n    <div data-dojo-attach-point=\"boostingEditorNode\"></div>\n    <div data-dojo-attach-point=\"boostingPreviewNode\"></div>\n</div>"}});
﻿define("epi-find/widget/Boosting", [
    "dojo/_base/declare",

    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/layout/_LayoutWidget",

    "./_ActionableMixin",
    "./_DisabledViewMixin",
    "./BoostingEditor",
    "./BoostingPreview",

    "dojo/i18n!./nls/Boosting",
    "dojo/text!./templates/Boosting.html"
],
    function(declare,
        _WidgetBase,
        _TemplatedMixin,

        _LayoutWidget,

        _ActionableMixin,
        _DisabledViewMixin,
        BoostingEditor,
        BoostingPreview,
        i18n,
        template) {

        // module:
        //      epi-find/widget/Connectors

        return declare([_WidgetBase, _LayoutWidget, _TemplatedMixin, _ActionableMixin, _DisabledViewMixin], {
            // summary:
            //     Manage view.

            templateString: template,

            i18n: i18n,

            model: null,

            boostingEditor: null,

            boostingPreview: null,

            postCreate: function() {
                this.inherited(arguments);
                if (!this.model) {
                    throw "No model specified";
                }

                this.boostingEditor = new BoostingEditor({
                    model: this.model.boostingEditorModel
                }, this.boostingEditorNode);
                this.own(this.boostingEditor);
                this.addChild(this.boostingEditor);

                this.boostingPreview = new BoostingPreview({
                    model: this.model.boostingPreviewModel,
                    scrollNode: this.scrollNode
                }, this.boostingPreviewNode);
                this.own(this.boostingPreview);
                this.addChild(this.boostingPreview);
            },

            layout: function() {
                this.boostingEditor.resize();
            },

            takeAction: function() {
                this.boostingEditor.refresh();
                return this;
            }
        });
    });