﻿define("epi-find/optimize/OptimizationController", [
    "dojo/_base/declare",

    "../_ControllerBase",
    "./OptimizationModel",
    "../widget/Optimization",
    "../widget/_ActionableMixin"
],
function(declare,
    _ControllerBase,
    OptimizationModel, Optimization, _ActionableMixin
) {
    return declare([_ControllerBase, _ActionableMixin], {
        // summary:
        //      Controller for Optimization views.

        model: null,
        widget: null,

        startup: function() {
            if (this.isStarted()) {
                return;
            }
            this.inherited(arguments);
            this.model = new OptimizationModel();
            this.model.init();

            this.widget = new Optimization({
                model: this.model
            });

            this.own(this.widget);
        },

        show: function() {
            this._setupView([this.widget]);
        },

        takeAction: function(actions, params) {
            this.widget.takeAction(actions, params);
            this.currentAction = this.widget.currentAction;
            return this.widget;
        }
    });
});