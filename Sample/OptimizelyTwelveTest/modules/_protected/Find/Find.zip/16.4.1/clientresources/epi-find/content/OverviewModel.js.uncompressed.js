﻿define("epi-find/content/OverviewModel", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/when",
    "dojo/Stateful",
    "dojo/_base/config",

    "dijit/Destroyable",

    "../ConfigModel",
    "../ApplicationState"
],
function (declare,
          lang,
          array,
          when,
          Stateful,
          config,
          Destroyable,
          ConfigModel,
          ApplicationState) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      Overview model.

        store: null,

        totalDocuments: null,
        totalDocumentTypes: null,
        documentTypes: null,

        contentTypes: null,
        totalContentTypes: null,
        totalContentItems: null,
        totalMediaItems: null,

        totalLanguageBranches: null,
        languageBranches: null,

        documentInfoError: null,
        cmsInfoError: null,

        indexName: null,
        findApiVersion: null,

        facetSize: 100,

        // config: object
        //      Configuration parameters
        config: null,
        _configSetter: function(value) {
            if (!value) {
                return;
            }
            this.set("indexName", value.index_name);
            this.set("findApiVersion", value.find_api_version);
        },

        site: null,
        _siteSetter: function (site) {
            this.site = site;
            this._updateSiteFilter(site);
        },

        documentsInfoQuery: null,

        contentInfoQuery: null,

        mediaInfoQuery: null,

        _siteFilter: null,

        postscript: function() {
            this.inherited(arguments);
            if (!this.store) {
                this.store = config.dependencies["epi-find.ElasticsearchStore"];
            }

            this._siteFilter = {};
        },

        init: function () {
            //  summary:
            //      Sets the model properties to initial state.
            //      This method should be called when widgets are instantiated and subscribed on model updates,
            //      so that when this method is called dependent widgets will get initial values from the model.
            var self = this;

            this.documentTypes = [];
            this.contentTypes = [];
            this.languageBranches = [];

            this.set("site", ApplicationState.site || null);
            this.own(ApplicationState.watch("site", function (name, oldValue, site) {
                self.set("site", site);
                self.load();
            }));
        },

        load: function() {
            this._buildQuery();
            this.loadDocumentsInfo();
            this.loadContentInfo();
            this.loadMediaInfo();
            this.loadConfigInfo();
        },

        loadConfigInfo: function () {
            var self = this;
            // read current configuration
            this.set("config", ConfigModel.config);
            // and watch for configuration changes
            this.own(ConfigModel.watch("config", function(name, oldValue, value) {
                self.set("config", value);
            }));
        },

        loadDocumentsInfo: function () {
            this.set("documentInfoError", null);
            var documentQuery = this.store.query(this.documentsInfoQuery);

            when(documentQuery.facets, lang.hitch(this, function (facets) {
                this.set("totalDocuments", facets.type.total);
                this.set("totalDocumentTypes", facets.type.terms.length);
                this.set("documentTypes", facets.type.terms);
            }), lang.hitch(this, function (error) {
                this.set("documentInfoError", error);
            }));
        },

        loadContentInfo: function () {
            this.set("cmsInfoError", null);
            var cmsContentQuery = this.store.query(this.contentInfoQuery);

            when(cmsContentQuery.total, lang.hitch(this, function (totalContentItems) {
                this.set("totalContentItems", totalContentItems);
            }), lang.hitch(this, function (error) {
                this.set("cmsInfoError", error);
            }));

            when(cmsContentQuery.facets, lang.hitch(this, function (facets) {
                this.set("contentTypes", facets.contentType.terms);
                this.set("totalContentTypes", facets.contentType.terms.length);

                this.set("languageBranches", facets.language.terms);
                this.set("totalLanguageBranches", facets.language.terms.length);
            }), lang.hitch(this, function (error) {
                this.set("cmsInfoError", error);
            }));
        },

        loadMediaInfo: function () {
            this.set("cmsInfoError", null);
            var cmsMediaCountQuery = this.store.query(this.mediaInfoQuery);

            when(cmsMediaCountQuery.total, lang.hitch(this, function (totalMediaItems) {
                this.set("totalMediaItems", totalMediaItems);
            }), lang.hitch(this, function (error) {
                this.set("cmsInfoError", error);
            }));
        },

        _buildQuery: function() {
            //  summary:
            //      Builds ElasticSearch query based on model parameters.
            this.documentsInfoQuery = {
                size: 0,
                query: {
                    "filtered": {
                        "query": {
                            "match_all": {}
                        },
                        "filter": this._siteFilter
                    }
                },
                facets: {
                    type: {
                        terms: {
                            field: "$type",
                            size: this.facetSize
                        }
                    }
                }
            };

            this.contentInfoQuery = {
                query: {
                    filtered: {
                        query: {
                            constant_score: {
                                filter: {
                                    not: {
                                        filter: {
                                            or: [
                                                {
                                                    term: {
                                                        ___types: "EPiServer.Core.IContentMedia"
                                                    }
                                                },
                                                {
                                                    term: {
                                                        ___types: "EPiServer.Core.ContentFolder"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        },
                        filter: {
                            "and": [
                                {
                                    "term": {
                                        "___types": "EPiServer.Core.IContent"
                                    }
                                },
                                this._siteFilter
                            ]
                        }
                    }
                },
                facets: {
                    contentType: {
                        terms: {
                            // TODO: Use _TypeShortName instead, when that has been merged into Owl
                            field: "ContentTypeName$$string",
                            size: this.facetSize
                        }
                    },
                    language: {
                        terms: {
                            field: "Language.Name$$string",
                            size: this.facetSize
                        }
                    }
                }
            };

            this.mediaInfoQuery = {
                "size": 0,
                "query": {
                    "filtered": {
                        "query": {
                            "match_all": {}
                        },
                        "filter": {
                            "and": [
                                {
                                    "term": {
                                        "___types": "EPiServer.Core.IContentMedia"
                                    }
                                },
                                this._siteFilter
                            ]
                        }
                    }
                }
            };
        },

        _updateSiteFilter: function (site) {
            var siteId = site ? site.id : null,
                siteName = site ? site.name : null;

            if (siteId) {
                this._addSiteFilter(siteId, siteName);
            }
            else {
                this._removeSiteFilter();
            }
        },

        _addSiteFilter: function (siteId, siteName) {
            if (!siteId) {
                return;
            }

            this._siteFilter.or = [
                {
                    "term": {
                        "SiteId$$string": siteId
                    }

                }
            ];

            if (siteName) {
                this._siteFilter.or.push({
                    "term": {
                        "SiteId$$string": siteName
                    }
                });
            }
        },

        _removeSiteFilter: function () {
            delete this._siteFilter.or;
        }
    });
});
