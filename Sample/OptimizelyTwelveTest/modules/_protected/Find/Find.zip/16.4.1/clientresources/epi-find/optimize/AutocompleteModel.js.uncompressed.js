define("epi-find/optimize/AutocompleteModel", [
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/regexp",

    "dojo/when",

    "dojo/Stateful",
    "dijit/Destroyable",

    "dojox/mvc/EditStoreRefController",
    "epi-saas-base/mvc/_CommitReturnMixin",
    "epi-saas-base/mvc/_EmptiableRefControllerMixin"
],
    function(declare,
             Deferred,
             regexp,
             when,
             Stateful,
             Destroyable,
             EditStoreRefController,
             _CommitReturnMixin,
             _EmptiableRefControllerMixin) {

        // module:
        //      epi-find/manage/RelatedQueriesModel

        var SearchQuery = function(value, properties) {
            // summary:
            //      This is a native JavaScript object used as a query when requesting backend store.

            this.properties = (properties instanceof Array) ?  properties : [properties];
            this.value = value;

            this.toString = function() {
                return this.value;
            };

            this.test = function(property, object) {
                // summary:
                //      This method used when dojo/store/Observable tries to verify if an object that was just
                //      updated matches to the current query. By default dojo/store/util/SimpleQueryEngine is used
                //      to verify, if an object matches with the current query. It has an ability to provide
                //      a custom verification logic by implementing a 'test' method.

                // replace asterisks and question mark with a correspondent regular expressions
                var escapedValue = regexp.escapeString(this.value, "*?").replace("*", ".*").replace("?", "."),
                    regularExpression = new RegExp(escapedValue, "i"),
                    result = false;
                for (var i=0; i<this.properties.length; i++) {
                    var testValue = object[this.properties[i]];
                    result = result || regularExpression.test(testValue);
                }
                return result;
            };
        };

        return declare([Stateful, Destroyable], {
            // summary:
            //     Model for the Autocomplete view.

            // store: dojo/store/JsonRest
            //      A store that is used for saving data
            store: null,

            // ctrl: dojox/mvc/EditStoreRefController
            //      A controller for binding
            ctrl: null,

            // searchText: String
            //      A search query
            searchText: null,
            _searchTextSetter: function(value) {
                if (value) {
                    var queryValue = {q: new SearchQuery(value + "*", "query")};
                    this.set("gridQuery", queryValue);
                }
                else {
                    this.set("gridQuery", {});
                }
            },

            // gridQuery: Object
            //      Query for the grid
            gridQuery: null,

            postscript: function() {
                this.inherited(arguments);
                var BindingController = declare([EditStoreRefController, _CommitReturnMixin, _EmptiableRefControllerMixin]);
                this.ctrl = new BindingController({
                    store: this.store,
                    emptyModel: new Stateful({priority:1})
                });
                this.gridQuery = {};
            },

            save: function() {
                if (!this.store.getIdentity(this.ctrl.sourceModel)) { // if this is a new item
                    var self = this, results = new Deferred();
                    // calculate priority value for a new item
                    when(this.store.query({}, {
                        start:0,
                        count: 1,
                        sort: [
                            {attribute: "priority", descending: true}
                        ]
                    }), function(topItem) {
                        var topPriority = 0;
                        if (topItem && topItem.length) {
                            topPriority = topItem[0].priority;
                        }
                        // priority for new items is calculated as a quarter of the difference between
                        // maximal priority of existing item and maximal possible priority
                        var newPriority = topPriority + Math.round((self.store.maxPriority - topPriority) / 4);
                        self.ctrl.set("priority", newPriority);
                        when(self.ctrl.commit(), function(commitResults) {
                            if (newPriority === topPriority) {
                                setTimeout(function() {self.store.emit("refresh");}, 2000); // init displayed data refresh
                            }
                            results.resolve(commitResults);
                        }, function(error) {
                            results.reject(error);
                        });
                    }, function(error) {
                        results.reject(error);
                    });
                    return results;
                }
                return this.ctrl.commit();
            },

            remove: function(id) {
                // summary:
                //      Removes an autocomplete entry with specified ID
                return this.store.remove(id);
            }

        });
    });