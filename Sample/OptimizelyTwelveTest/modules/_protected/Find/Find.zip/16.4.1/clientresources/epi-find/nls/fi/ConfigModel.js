//>>built
define("epi-find/nls/fi/ConfigModel",{"configErrorMessage":"Virhe luettaessa määritystä."});