//>>built
define("epi-find/nls/no/ConfigModel",{"configErrorMessage":"Kunne ikke lese konfigurasjon."});